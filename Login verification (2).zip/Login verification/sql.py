import sqlite3

conn = sqlite3.connect("users.sqlite3")

cursor = conn.cursor()

cursor.execute("""
        create table if not exists pokemon
        (
            id integer primary key autoincrement,
            username varchar(50) NOT NULL,
            password varchar(30) NOT NULL,
            email varchar(100) NOT NULL
        )
             
              """)

conn.commit()
conn.close()